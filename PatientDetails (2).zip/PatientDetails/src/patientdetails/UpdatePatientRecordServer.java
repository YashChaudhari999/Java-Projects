// package PatientDetails.src.patientdetails;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.logging.Level;
import java.util.logging.Logger;

import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoDatabase;
import com.mongodb.*;
import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.MongoCollection;
import org.bson.Document;

/**
 *
 * @author Yash
 */
public class UpdatePatientRecordServer {

    public static void main(String[] args) {
        alwaysConnected();
    }

    public static void alwaysConnected() {
        try (ServerSocket serverSocket = new ServerSocket(1945)) {
            String updatePatientIDTextField_Data, updateNameTextField_Data, updateContactNumberTextField_Data,
                    updateAgeTextField_Data,
                    updateGenderButtonGroup_Data,
                    updateBloodGroupList_Data, updateAddressTextArea_Data, updateMajorDiseaseTextArea_Data;

            System.out.println("Server is waiting for connections...");
            System.out.println("Waiting for Clients....");
            Socket clientSocket = serverSocket.accept();
            System.err.println("Connection Estabilished");
            BufferedReader in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
            PrintWriter out = new PrintWriter(clientSocket.getOutputStream(), true);
            updatePatientIDTextField_Data = in.readLine();
            updateNameTextField_Data = in.readLine();
            updateContactNumberTextField_Data = in.readLine();
            updateAgeTextField_Data = in.readLine();
            updateGenderButtonGroup_Data = in.readLine();
            updateBloodGroupList_Data = in.readLine();
            updateAddressTextArea_Data = in.readLine();
            updateMajorDiseaseTextArea_Data = in.readLine();
            System.out.println(updatePatientIDTextField_Data + updateNameTextField_Data +
                    updateContactNumberTextField_Data +
                    updateAgeTextField_Data +
                    updateGenderButtonGroup_Data +
                    updateBloodGroupList_Data + updateAddressTextArea_Data + updateMajorDiseaseTextArea_Data);

            MongoClient mongo1 = MongoClients.create("mongodb://localhost:27017");
            MongoDatabase db1 = mongo1.getDatabase("Hospital");
            MongoCollection collection = db1.getCollection("PatientData");

            Document filter = new Document("PatientID", updatePatientIDTextField_Data);

            Document updatedDocument = new Document("PatientName", updateNameTextField_Data)
                    .append("PatientContact", updateContactNumberTextField_Data)
                    .append("PatientAge", updateAgeTextField_Data)
                    .append("PatientGender", updateGenderButtonGroup_Data)
                    .append("PatientBloodGroup", updateBloodGroupList_Data)
                    .append("PatientAddress", updateAddressTextArea_Data)
                    .append("PatientMajorDisease", updateMajorDiseaseTextArea_Data);
  
            Document updateOperation = new Document("$set", updatedDocument);

            collection.updateOne(filter, updateOperation);
        } catch (IOException ex) {
            Logger.getLogger(UpdatePatientRecordServer.class.getName()).log(Level.SEVERE, null, ex);
        }
        alwaysConnected();
    }
}