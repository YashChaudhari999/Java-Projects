import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class DB {
	public static Connection getConnection(){
		Connection con=null;
		// try{
			// 	Class.forName("com.mysql.jdbc.Driver");
			// 	con=DriverManager.getConnection("jdbc:mysql://localhost:3306/test","lms","lms");
			// }catch(Exception e){System.out.println(e);}
			// return con;
			try {
				// Load the MySQL JDBC driver
            Class.forName("com.mysql.jdbc.Driver");

            // Establish a database connection
            String url = "jdbc:mysql://localhost:3306/test";
            String username = "lms";
            String password = "lms";
            con = DriverManager.getConnection(url, username, password);


        } catch (ClassNotFoundException e) {
            System.err.println("MySQL JDBC driver not found.");
        } catch (SQLException e) {
            System.err.println("Error while establishing the database connection.");
            e.printStackTrace();
		}
			return con;
	}
      
}
